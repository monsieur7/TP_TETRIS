

/**
  Section: Included Files
*/
#define SSD1331_CMD_DRAWLINE 		    0x21
#define SSD1331_CMD_DRAWRECT 		    0x22
#define SSD1331_CMD_FILL 			    0x26
#define SSD1331_CMD_SETCOLUMN           0x15
#define SSD1331_CMD_SETROW              0x75
#define SSD1331_CMD_CONTRASTA           0x81
#define SSD1331_CMD_CONTRASTB           0x82
#define SSD1331_CMD_CONTRASTC		    0x83
#define SSD1331_CMD_MASTERCURRENT       0x87
#define SSD1331_CMD_SETREMAP 		    0xA0
#define SSD1331_CMD_STARTLINE           0xA1
#define SSD1331_CMD_DISPLAYOFFSET       0xA2
#define SSD1331_CMD_NORMALDISPLAY       0xA4
#define SSD1331_CMD_DISPLAYALLON        0xA5
#define SSD1331_CMD_DISPLAYALLOFF       0xA6
#define SSD1331_CMD_INVERTDISPLAY       0xA7
#define SSD1331_CMD_SETMULTIPLEX        0xA8
#define SSD1331_CMD_SETMASTER           0xAD
#define SSD1331_CMD_DISPLAYOFF          0xAE
#define SSD1331_CMD_DISPLAYON           0xAF
#define SSD1331_CMD_POWERMODE           0xB0
#define SSD1331_CMD_PRECHARGE           0xB1
#define SSD1331_CMD_CLOCKDIV 		    0xB3
#define SSD1331_CMD_PRECHARGEA          0x8A
#define SSD1331_CMD_PRECHARGEB          0x8B
#define SSD1331_CMD_PRECHARGEC          0x8C
#define SSD1331_CMD_PRECHARGELEVEL      0xBB
#define SSD1331_CMD_VCOMH 			    0xBE 

// enhanced constants & commands added by SEMU
#define SSD1331_CMD_COPY            0x23
#define SSD1331_CMD_DIM             0x24
#define SSD1331_CMD_CLEAR           0x25
#define SSD1331_FILL_OFF            0x00
#define SSD1331_FILL_ON             0x01
#define SSD1331_CMD_SETGRAYSCALE	  0xB8
#define SSD1331_CMD_RESETGRAYSCALE	0xB9

#define SSD1331_CMD_SETSCROLL       0x27
#define SSD1331_CMD_SCROLLOFF       0x2E
#define SSD1331_CMD_SCROLLON        0x2F



#include "mcc_generated_files/system.h"
#include "mcc_generated_files/pin_manager.h"
#include "OLED.h"
#define FCY 8000000UL
#include <libpic30.h>

/*
                         Main application
 */
int main(void)
{
    SYSTEM_Initialize();
    
    PowerOnSequence();
    
    setAddrWindow(0,0,96,64);
    
    char array[12*12] = {0};
    for(char y = 0; y < 12; y++){
        for(char x = 0; x < 12; x++){
                array[y*12+x] = 0xB5;
            
        }
    }

           

    while (1)
    {
          // initialize the device
        LCD_sendPixelArray(10, 10, 12, 12, array);
    }

    return 1;
}
/**
 End of File
*/
void sendCommand(int command){
    CS_SetLow();
    DC_SetLow();
    SPI1_Exchange8bit(command);
    __delay_us(5);
    CS_SetHigh();
}

void sendData(int data){
    CS_SetLow();
    DC_SetHigh();
    SPI1_Exchange8bit(data);
    __delay_us(5);
    CS_SetHigh();
}

void PowerOnSequence(){
    DC_SetLow();
    RES_SetHigh();
    //VCCEN_SetLow();
   // PMODEN_SetHigh();
    __delay_ms(20);
    RES_SetLow();
    __delay_us(3);
    RES_SetHigh();
    __delay_us(3);
    
    sendCommand(0xFD);
    sendCommand(0x12);
    
    sendCommand(SSD1331_CMD_DISPLAYOFF); // 0xAE
    sendCommand(SSD1331_CMD_SETREMAP);   // 0xA0

    sendCommand(0x72); // RGB Color


    sendCommand(SSD1331_CMD_STARTLINE); // 0xA1
    sendCommand(0x0);
    sendCommand(SSD1331_CMD_DISPLAYOFFSET); // 0xA2
    sendCommand(0x0);
    sendCommand(SSD1331_CMD_NORMALDISPLAY); // 0xA4
    sendCommand(SSD1331_CMD_SETMULTIPLEX);  // 0xA8
    sendCommand(0x3F);                      // 0x3F 1/64 duty
    sendCommand(SSD1331_CMD_SETMASTER);     // 0xAD
    sendCommand(0x8E);
    sendCommand(SSD1331_CMD_POWERMODE); // 0xB0
    sendCommand(0x0B);
    sendCommand(SSD1331_CMD_PRECHARGE); // 0xB1
    sendCommand(0x31);
    sendCommand(SSD1331_CMD_CLOCKDIV); // 0xB3
    sendCommand(0xF0); // 7:4 = Oscillator Frequency, 3:0 = CLK Div Ratio
                     // (A[3:0]+1 = 1..16)
    sendCommand(SSD1331_CMD_PRECHARGEA); // 0x8A
    sendCommand(0x64);
    sendCommand(SSD1331_CMD_PRECHARGEB); // 0x8B
    sendCommand(0x78);
    sendCommand(SSD1331_CMD_PRECHARGEC); // 0x8C
    sendCommand(0x64);
    sendCommand(SSD1331_CMD_PRECHARGELEVEL); // 0xBB
    sendCommand(0x3A);
    sendCommand(SSD1331_CMD_VCOMH); // 0xBE
    sendCommand(0x3E);
    sendCommand(SSD1331_CMD_MASTERCURRENT); // 0x87
    sendCommand(0x06);
    sendCommand(SSD1331_CMD_CONTRASTA); // 0x81
    sendCommand(0x91);
    sendCommand(SSD1331_CMD_CONTRASTB); // 0x82
    sendCommand(0x50);
    sendCommand(SSD1331_CMD_CONTRASTC); // 0x83
    sendCommand(0x7D);
    sendCommand(0x2E);
    sendCommand(0x25);
    sendCommand(0x0);
    sendCommand(0x0);
    sendCommand(0x5F);
    sendCommand(0x3F);
    //VCCEN_SetHigh();
    __delay_ms(25);
    
    sendCommand(SSD1331_CMD_DISPLAYON); //--turn on oled panel
    __delay_ms(100);
    
}

static const int16_t TFTWIDTH = 96;    ///< The width of the display
static const int16_t TFTHEIGHT = 64;   ///< The height of the display

  void setAddrWindow(uint16_t x, uint16_t y, uint16_t w, uint16_t h) {
    
    uint8_t x1 = x;
    uint8_t y1 = y;
    if (x1 > TFTWIDTH-1) x1 = TFTWIDTH-1;
    if (y1 > TFTHEIGHT-1) y1 = TFTHEIGHT-1;

    uint8_t x2 = (x+w-1);
    uint8_t y2 = (y+h-1);
    if (x2 > TFTWIDTH-1) x2 = TFTWIDTH-1;
    if (y2 > TFTHEIGHT-1) y2 = TFTHEIGHT-1;

    if (x1 > x2) {
      uint8_t t = x2;
      x2 = x1;
      x1 = t;
    }
    if (y1 > y2) {
      uint8_t t = y2;
      y2 = y1;
      y1 = t;
    }

    sendCommand(SSD1331_CMD_SETCOLUMN); // Column addr set
    sendCommand(x1);
    sendCommand(x2);
    sendCommand(SSD1331_CMD_SETROW); // Row addr set
    sendCommand(y1);
    sendCommand(y2);
}

void addPixels(int column, int row, int red, int green, int blue){
    sendCommand(SSD1331_CMD_SETCOLUMN); // Column addr set
    sendCommand(column);
    sendCommand(SSD1331_CMD_SETROW); // Row addr set
    sendCommand(row);
    sendCommand((green & 0x07) | ((red & 0x1F) << 3));
    sendCommand((blue & 0x1F) | ((green & 0x07) << 5));
}